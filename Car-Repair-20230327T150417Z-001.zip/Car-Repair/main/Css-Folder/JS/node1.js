const { readFileSync } = require("fs");
var http = require("http");

const htmlFile = readFileSync("./index.html")
const htmlFile1 = readFileSync("./services.html")
const htmlFile2 = readFileSync("./details1.html")

function samp(req, res) {
  if (req.url == "/") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(htmlFile);
  } else if (req.url == "/mobile") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(htmlFile1);
  } else if (req.url == "/laptop") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(htmlFile2);
  }
    else {
    res.end("invalid request");
  }
}
var server = http.createServer(samp);
server.listen(5700);
console.log("server running");